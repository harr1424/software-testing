John Harrington
Assignment One
Softeare Readability and Testing 

Note that the three .yaml files used for the commander tests can be ran at once by saving the text file
test_descriptions.txt as commander.yaml and moving or copying the files contained in the directory test_files to 
the directory where ./commander.sh test is executed. 
